package com.webage.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.webage.entity.Product;

@RepositoryRestResource(collectionResourceRel="product", path ="productsREST")
public interface ProductRepository extends CrudRepository<Product, Long> {
	public Iterable<Product> findByCategory(@Param("category") String category);
	public Iterable<Product> findByCategoryAndPriceLessThan(@Param("category") String category, @Param("price") double price);
	public Iterable<Product> findByPriceLessThan(@Param("price") double price);
}
