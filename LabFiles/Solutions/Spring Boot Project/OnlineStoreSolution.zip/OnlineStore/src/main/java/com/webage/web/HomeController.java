package com.webage.web;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
class HomeController {
	@RequestMapping("/")
	public String index(Model model, @Value("${app.home.title}") String title) {
		model.addAttribute("title", title);
 		return "home";
	}

}
