package com.webage.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.webage.entity.Product;
import com.webage.repository.ProductRepository;

@Component
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository repository;

	@Override
	public Product find(long id) {
		return repository.findOne(id);
	}

	@Override
	public Collection<Product> productSearch(String category, double maxPrice) {
		if (category.equalsIgnoreCase("ALL")) {
			if (maxPrice <= 0) {
				return (Collection<Product>) repository.findAll();
			} else {
				return (Collection<Product>) repository.findByPriceLessThan(maxPrice);
			}
		} else {
			if (maxPrice <= 0) {
				return (Collection<Product>) repository.findByCategory(category);
			} else {
				return (Collection<Product>) repository.findByCategoryAndPriceLessThan(category, maxPrice);
			}
		}
	}

}
