package com.webage.web;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.webage.entity.Product;
import com.webage.service.ProductService;

@Controller
@RequestMapping("/products")
class ProductSearchController {
	@Autowired
	private ProductService service;
	
	@ModelAttribute(value = "title")
	public String getTitle(@Value("${app.products.title}") String title) {
		 return title;
	}
	
	@ModelAttribute(value = "subTitle")
 	public String getSubTitle() {
		 return "Search for Products";
	}

	@ModelAttribute(value = "categoryNames")
	public List<String> getNames() {
		List<String> list = new ArrayList<String>();
		list.add("ALL");
		list.add("Electronics");
		list.add("Sports");
		list.add("School");
		return list;
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public String displayForm(Model model) {
		model.addAttribute("maxPrice", 0.0);
		return "products";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String productSearch(Model model, @RequestParam("category") String category,
			@RequestParam("maxPrice") double maxPrice) {
		Collection<Product> products = service.productSearch(category, maxPrice);
		if (products.size() == 0) {
			throw new RuntimeException("NO products match!");
		}
	  	model.addAttribute("products", products);
		model.addAttribute("maxPrice", maxPrice);
		return "products";
	}

}
