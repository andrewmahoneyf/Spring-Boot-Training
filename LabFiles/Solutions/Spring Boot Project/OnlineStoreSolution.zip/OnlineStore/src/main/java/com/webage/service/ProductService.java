package com.webage.service;

import java.util.Collection;

import com.webage.entity.Product;

public interface ProductService {
	public Product find(long id);

	public Collection<Product> productSearch(String category, double maxPrice);
}
