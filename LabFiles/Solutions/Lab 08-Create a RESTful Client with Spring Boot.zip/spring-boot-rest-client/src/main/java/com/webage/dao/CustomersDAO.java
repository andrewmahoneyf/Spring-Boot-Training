package com.webage.dao;

import java.util.Collection;

import com.webage.domain.Customer;

public interface CustomersDAO {
	public Collection<Customer> getAllCustomers();
}
