package com.webage.spring.samples.helloclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class HelloAPIFallback implements HelloAPI {

  @Override
  public Map<String, Object> getGreeting(String name) {
    Map<String,Object> resp=new HashMap<String,Object>();
    resp.put("message", "Fallback");
    return resp;
  }

}
